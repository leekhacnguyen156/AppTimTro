package com.example.timtro.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class mTin {

    @SerializedName("matin")
    @Expose
    private String matin;
    @SerializedName("mataikhoan")
    @Expose
    private String mataikhoan;
    @SerializedName("maloaitin")
    @Expose
    private String maloaitin;
    @SerializedName("maloaiphong")
    @Expose
    private String maloaiphong;
    @SerializedName("tentieude")
    @Expose
    private String tentieude;
    @SerializedName("matinh")
    @Expose
    private String matinh;
    @SerializedName("mahuyen")
    @Expose
    private String mahuyen;
    @SerializedName("diachi")
    @Expose
    private String diachi;
    @SerializedName("tenlienhe")
    @Expose
    private String tenlienhe;
    @SerializedName("sdt")
    @Expose
    private String sdt;
    @SerializedName("giaphong")
    @Expose
    private String giaphong;
    @SerializedName("dientich")
    @Expose
    private String dientich;
    @SerializedName("motachitiet")
    @Expose
    private String motachitiet;
    @SerializedName("trangthaiduyet")
    @Expose
    private String trangthaiduyet;
    @SerializedName("thoigiandang")
    @Expose
    private String thoigiandang;
    @SerializedName("trangthaidat")
    @Expose
    private String trangthaidat;
    @SerializedName("image")
    @Expose
    private String image;

    public String getTenlienhe() {
        return tenlienhe;
    }

    public void setTenlienhe(String tenlienhe) {
        this.tenlienhe = tenlienhe;
    }

    public String getMatin() {
        return matin;
    }

    public void setMatin(String matin) {
        this.matin = matin;
    }

    public String getMataikhoan() {
        return mataikhoan;
    }

    public void setMataikhoan(String mataikhoan) {
        this.mataikhoan = mataikhoan;
    }

    public String getMaloaitin() {
        return maloaitin;
    }

    public void setMaloaitin(String maloaitin) {
        this.maloaitin = maloaitin;
    }

    public String getMaloaiphong() {
        return maloaiphong;
    }

    public void setMaloaiphong(String maloaiphong) {
        this.maloaiphong = maloaiphong;
    }

    public String getTentieude() {
        return tentieude;
    }

    public void setTentieude(String tentieude) {
        this.tentieude = tentieude;
    }

    public String getMatinh() {
        return matinh;
    }

    public void setMatinh(String matinh) {
        this.matinh = matinh;
    }

    public String getMahuyen() {
        return mahuyen;
    }

    public void setMahuyen(String mahuyen) {
        this.mahuyen = mahuyen;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getGiaphong() {
        return giaphong;
    }

    public void setGiaphong(String giaphong) {
        this.giaphong = giaphong;
    }

    public String getDientich() {
        return dientich;
    }

    public void setDientich(String dientich) {
        this.dientich = dientich;
    }

    public String getMotachitiet() {
        return motachitiet;
    }

    public void setMotachitiet(String motachitiet) {
        this.motachitiet = motachitiet;
    }

    public String getTrangthaiduyet() {
        return trangthaiduyet;
    }

    public void setTrangthaiduyet(String trangthaiduyet) {
        this.trangthaiduyet = trangthaiduyet;
    }

    public String getThoigiandang() {
        return thoigiandang;
    }

    public void setThoigiandang(String thoigiandang) {
        this.thoigiandang = thoigiandang;
    }

    public String getTrangthaidat() {
        return trangthaidat;
    }

    public void setTrangthaidat(String trangthaidat) {
        this.trangthaidat = trangthaidat;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}