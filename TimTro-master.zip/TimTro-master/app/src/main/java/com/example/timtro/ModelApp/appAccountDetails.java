package com.example.timtro.ModelApp;

public class appAccountDetails {
    public static final String mataikhoan = "mataikhoan";
    public static final String tentinh = "tentinh";
    public static final String matinh = "matinh";
    public static final String mahuyen = "mahuyen";
    public static final String hovaten = "hovaten";
}
